import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext' // Sesuaikan path ke AuthContext kamu

const AuthCallback = () => {
  const navigate = useNavigate()
  const { login } = useAuth()

  useEffect(() => {
    // 1. Ambil hash fragment dari URL (#access_token=...&expires_in=...)
    const hash = window.location.hash

    if (hash) {
      // Mengubah string hash menjadi URLSearchParams agar mudah dibaca
      const params = new URLSearchParams(hash.replace('#', '?'))
      const accessToken = params.get('access_token')

      if (accessToken) {
        // Buat object user dummy/default (karena nama/email nanti disinkronkan via token)
        const user = { 
          email: 'user@google.com', // Nanti otomatis ter-update saat hit API backend
          isGoogleUser: true 
        }

        // 2. Simpan token ke AuthContext / LocalStorage aplikasi kamu
        login(user, accessToken)

        // 3. Langsung lempar ke dashboard!
        navigate('/dashboard', { replace: true })
        return
      }
    }

    // Jika tidak ada hash atau gagal mengambil token, balikkan ke login
    navigate('/login', { replace: true })
  }, [navigate, login])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#121358] text-white">
      <div className="w-10 h-10 border-4 border-t-transparent border-teal-400 rounded-full animate-spin mb-4"></div>
      <p className="text-sm font-semibold tracking-wide">Menghubungkan akun Google kamu...</p>
    </div>
  )
}

export default AuthCallback