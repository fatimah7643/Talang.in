import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { createNotification } from './notificationController.js';

dotenv.config();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

/* ═══════════════════════════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════════════════════════ */

const logActivity = async (
  group_id,
  user_id,
  activity_type,
  description
) => {
  try {
    await supabase.from('activity_logs').insert([
      {
        group_id,
        user_id,
        activity_type,
        description,
      },
    ]);
  } catch (err) {
    console.warn('Gagal mencatat activity_log:', err.message);
  }
};

const isSamePerson = (fullName = '', aiName = '') => {
  const full = fullName.toLowerCase().trim();
  const ai = aiName.toLowerCase().trim();

  const first = full.split(' ')[0];

  return (
    full === ai ||
    first === ai ||
    full.includes(` ${ai}`) ||
    ai.includes(first)
  );
};

const checkDifferentAmounts = (arr = []) => {
  if (!arr || arr.length <= 1) return false;

  return !arr.every(
    p =>
      Number(p.amount ?? p.share_amount) ===
      Number(arr[0].amount ?? arr[0].share_amount)
  );
};

const parseNominal = str => {
  if (!str) return 0;

  let cleaned = str.toString().toLowerCase().trim();

  // 1,5jt => 1.5jt
  cleaned = cleaned.replace(
    /(\d+),(\d+)(jt|juta|k|rb|ribu)/gi,
    '$1.$2$3'
  );

  const decimalMultiplierPattern =
    /(\d+\.\d+)\s*(jt|juta|k|rb|ribu)/gi;

  const match = decimalMultiplierPattern.exec(cleaned);

  if (match) {
    const num = parseFloat(match[1]);
    const unit = match[2];

    let factor = 1;

    if (['k', 'rb', 'ribu'].includes(unit)) {
      factor = 1000;
    }

    if (['jt', 'juta'].includes(unit)) {
      factor = 1000000;
    }

    return Math.floor(num * factor);
  }

  cleaned = cleaned
    .replace(/\./g, '')
    .replace(/,/g, '')
    .replace(/ribu/g, '000')
    .replace(/rb/g, '000')
    .replace(/k/g, '000')
    .replace(/juta/g, '000000')
    .replace(/jt/g, '000000')
    .trim();

  return parseInt(cleaned) || 0;
};

const extractAllNominalsFromText = text => {
  const pattern =
    /(\d+(?:[.,]\d+)*(?:k|rb|ribu|juta|jt)?)/gi;

  const matches = text.match(pattern) || [];

  return matches
    .map(m => parseNominal(m))
    .filter(n => n > 0);
};

const extractExplicitTotal = text => {
  const pattern =
    /(?:total|totalnya|jumlah|semua|sebesar)\s+(\d+(?:[.,]\d+)*(?:k|rb|ribu|juta|jt)?)/gi;

  let max = 0;
  let match;

  while ((match = pattern.exec(text)) !== null) {
    const val = parseNominal(match[1]);

    if (val > max) {
      max = val;
    }
  }

  return max;
};

const extractShortTitle = text => {
  return text
    .trim()
    .split(/\s+/)
    .slice(0, 4)
    .join(' ')
    .replace(/[.,!?]+$/, '');
};

const extractPersonAmountsFromText = (
  text,
  knownMembers
) => {
  const result = {};

  const lines = text
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean);

  const payerKeywords =
    /dibayarin|dibayar\s+oleh|ditagih|yang\s+bayar|yang\s+keluar\s+duit/i;

  for (const line of lines) {
    if (payerKeywords.test(line)) continue;

    for (const member of knownMembers) {
      const firstName = member.split(' ')[0];

      const escapedName = firstName.replace(
        /[.*+?^${}()|[\]\\]/g,
        '\\$&'
      );

      const pStart = new RegExp(
        `^(?:bagian\\s+)?${escapedName}[:\\s]+(–|-)?(?:(?:total|sebesar|jumlah)\\s+)?(\\d+(?:[.,]\\d+)*(?:k|rb|ribu|juta|jt)?)`,
        'i'
      );

      const pMid = new RegExp(
        `(?:^|\\b)${escapedName}\\s+(?:(?:total|sebesar|jumlah)\\s+)?(\\d+(?:[.,]\\d+)*(?:k|rb|ribu|juta|jt)?)`,
        'i'
      );

      const match = pStart.exec(line) || pMid.exec(line);

      if (match) {
        const rawNominal = match[match.length - 1];

        const nominal = parseNominal(rawNominal);

        if (nominal > 0) {
          result[firstName] =
            (result[firstName] || 0) + nominal;
        }

        break;
      }
    }
  }

  return result;
};

/* ═══════════════════════════════════════════════════════════════
   POST /api/v1/bills/split
═══════════════════════════════════════════════════════════════ */

export const splitBill = async (req, res) => {
  try {
    const {
      group_id,
      payer_id,
      amount,
      description,
      title,
      category,
      splits,
    } = req.body;

    const billDescription = description || title;

    if (
      !group_id ||
      !payer_id ||
      !amount ||
      !billDescription ||
      !splits ||
      !Array.isArray(splits) ||
      splits.length === 0
    ) {
      return res.status(400).json({
        success: false,
        message:
          'group_id, payer_id, amount, description, dan splits wajib diisi!',
      });
    }

    // Hindari payer ikut punya hutang
    const nonPayerSplits = splits.filter(
      s =>
        s.member_id !== payer_id &&
        s.profile_id !== payer_id
    );

    const totalAll = splits.reduce(
      (sum, s) => sum + Number(s.share_amount),
      0
    );

    if (totalAll > Number(amount) + 1) {
      return res.status(400).json({
        success: false,
        message: `Total split (${totalAll}) melebihi total amount (${amount})!`,
      });
    }

    const splitMethod = checkDifferentAmounts(
      nonPayerSplits
    )
      ? 'custom'
      : 'equal';

    const { data: billData, error: billError } =
      await supabase
        .from('bills')
        .insert([
          {
            group_id,
            payer_id,
            amount: Number(amount),
            description: billDescription,
            category: category || 'Lainnya',
            split_method: splitMethod,
          },
        ])
        .select()
        .single();

    if (billError) throw billError;

    const splitRows = nonPayerSplits.map(s => ({
      bill_id: billData.id,
      member_id: s.member_id,
      share_amount: Number(s.share_amount),
      amount_paid: 0,
      is_paid: false,
    }));

    const { data: splitData, error: splitError } =
      await supabase
        .from('bill_splits')
        .insert(splitRows)
        .select();

    if (splitError) throw splitError;

    await logActivity(
      group_id,
      payer_id,
      'BILL_CREATED',
      `Tagihan "${billDescription}" sebesar Rp${Number(
        amount
      ).toLocaleString()}`
    );

    await Promise.all(
      nonPayerSplits.map(s =>
        createNotification({
          user_id: s.profile_id || s.member_id,
          type: 'transaction',
          title: `Tagihan baru: ${billDescription}`,
          message: `Kamu punya tagihan Rp${Number(
            s.share_amount
          ).toLocaleString()}`,
        })
      )
    );

    return res.status(201).json({
      success: true,
      message: 'Tagihan berhasil dibuat!',
      bill_summary: billData,
      split_details: splitData,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/* ═══════════════════════════════════════════════════════════════
   POST /api/v1/bills/split-nlp
═══════════════════════════════════════════════════════════════ */

export const splitBillNLP = async (req, res) => {
  try {
    const {
      group_id,
      raw_text,
      group_members,
    } = req.body;

    if (
      !group_id ||
      !raw_text ||
      !group_members ||
      !Array.isArray(group_members)
    ) {
      return res.status(400).json({
        success: false,
        message:
          'group_id, raw_text, dan group_members wajib diisi!',
      });
    }

    // AI REQUEST
    const aiResponse = await fetch(
      `${process.env.AI_BASE_URL}/parse-transaction`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: raw_text,
          entities: [],
          group_members: group_members.map(
            m => m.name
          ),
        }),
      }
    );

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();

      throw new Error(
        `AI Error: ${aiResponse.status} - ${errText}`
      );
    }

    const aiResult = await aiResponse.json();

    if (aiResult.status !== 'success') {
      return res.status(400).json({
        success: false,
        message: 'AI gagal memproses transaksi',
        ai_response: aiResult,
      });
    }

    const entities = aiResult.rawEntities || [];

    // FIX paidBy array/string
    let rawPaidBy = '';

    if (Array.isArray(aiResult.paidBy)) {
      rawPaidBy = aiResult.paidBy[0] || '';
    } else if (typeof aiResult.paidBy === 'string') {
      rawPaidBy = aiResult.paidBy;
    } else {
      rawPaidBy =
        aiResult.paidBy?.name ||
        aiResult.paidBy?.text ||
        '';
    }

    const payerNorm = rawPaidBy
      .toLowerCase()
      .trim();

    let finalParticipants = [];
    let finalSplitMethod =
      aiResult.splitMethod || 'equal';

    const memberNames = group_members.map(
      m => m.name
    );

    const personAmountMap = {};

    for (let i = 0; i < entities.length; i++) {
      if (entities[i].label === 'PERSON') {
        const personName = entities[i].text;

        for (let j = i + 1; j < entities.length; j++) {
          if (entities[j].label === 'PRICE') {
            personAmountMap[personName] =
              (personAmountMap[personName] || 0) +
              parseNominal(entities[j].text);

            break;
          }

          if (entities[j].label === 'PERSON') {
            break;
          }
        }
      }
    }

    if (
      Object.keys(personAmountMap).length === 0
    ) {
      const fallback =
        extractPersonAmountsFromText(
          raw_text,
          memberNames
        );

      Object.assign(personAmountMap, fallback);
    }

    const allNominals =
      extractAllNominalsFromText(raw_text);

    const explicitTotal =
      extractExplicitTotal(raw_text);

    const maxNominal =
      allNominals.length > 0
        ? Math.max(...allNominals)
        : 0;

    const fallbackAmount =
      explicitTotal > 0
        ? explicitTotal
        : maxNominal;

    const hasCustom =
      Object.keys(personAmountMap).length > 0;

    if (hasCustom) {
      finalSplitMethod = 'custom';

      finalParticipants = group_members
        .map(m => {
          const firstName =
            m.name.split(' ')[0];

          const matchedKey = Object.keys(
            personAmountMap
          ).find(
            k =>
              k.toLowerCase() ===
                firstName.toLowerCase() ||
              k.toLowerCase() ===
                m.name.toLowerCase()
          );

          if (
            matchedKey &&
            !isSamePerson(m.name, payerNorm)
          ) {
            return {
              profile_id: m.profile_id,
              group_member_id:
                m.group_member_id,
              name: m.name,
              amount:
                personAmountMap[matchedKey],
            };
          }

          return null;
        })
        .filter(
          p => p !== null && p.amount > 0
        );
    } else {
      finalSplitMethod = 'equal';

      const debtors = group_members.filter(
        m => !isSamePerson(m.name, payerNorm)
      );

      if (debtors.length === 0) {
        return res.status(400).json({
          success: false,
          message:
            'Tidak ada partisipan valid!',
        });
      }

      const equalShare = Math.floor(
        fallbackAmount / debtors.length
      );

      const rem =
        fallbackAmount -
        equalShare * debtors.length;

      finalParticipants = debtors.map(
        (m, idx) => ({
          profile_id: m.profile_id,
          group_member_id:
            m.group_member_id,
          name: m.name,
          amount:
            idx === 0
              ? equalShare + rem
              : equalShare,
        })
      );
    }

    const payerMember = group_members.find(
      m =>
        isSamePerson(m.name, payerNorm) ||
        payerNorm.includes(
          m.name
            .split(' ')[0]
            .toLowerCase()
        )
    );

    if (!payerMember) {
      return res.status(400).json({
        success: false,
        message: `Pembayar "${rawPaidBy}" tidak ditemukan`,
      });
    }

    const billTitle =
      aiResult.title &&
      aiResult.title !== 'Unknown'
        ? aiResult.title
        : extractShortTitle(raw_text);

    const finalAmount =
      finalSplitMethod === 'custom'
        ? finalParticipants.reduce(
            (sum, p) => sum + p.amount,
            0
          )
        : aiResult.amount ||
          fallbackAmount;

    const { data: billData, error: billError } =
      await supabase
        .from('bills')
        .insert([
          {
            group_id,
            payer_id:
              payerMember.profile_id,
            amount: finalAmount,
            description: billTitle,
            category:
              aiResult.category ||
              'Lainnya',
            split_method:
              finalSplitMethod,
          },
        ])
        .select()
        .single();

    if (billError) throw billError;

    const splitRows = finalParticipants.map(
      p => ({
        bill_id: billData.id,
        member_id: p.group_member_id,
        share_amount: p.amount,
        amount_paid: 0,
        is_paid: false,
      })
    );

    if (splitRows.length > 0) {
      const { error: splitError } =
        await supabase
          .from('bill_splits')
          .insert(splitRows);

      if (splitError) throw splitError;
    }

    await logActivity(
      group_id,
      payerMember.profile_id,
      'BILL_CREATED',
      `Tagihan AI "${billTitle}" sebesar Rp${finalAmount.toLocaleString()}`
    );

    await Promise.all(
      finalParticipants.map(p =>
        createNotification({
          user_id: p.profile_id,
          type: 'transaction',
          title: `Tagihan baru: ${billTitle}`,
          message: `Kamu punya tagihan Rp${Number(
            p.amount
          ).toLocaleString()}`,
        })
      )
    );

    return res.status(201).json({
      success: true,
      message:
        'Tagihan berhasil dibuat via AI!',
      ai_parsed: {
        title: billTitle,
        amount: finalAmount,
        paidBy: rawPaidBy,
        category: aiResult.category,
        splitMethod: finalSplitMethod,
        participants: finalParticipants,
      },
      bill_summary: billData,
      split_count: splitRows.length,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/* ═══════════════════════════════════════════════════════════════
   GET BILL HISTORY
═══════════════════════════════════════════════════════════════ */

export const getBillHistory = async (
  req,
  res
) => {
  try {
    const { group_id } = req.params;

    const { data, error } = await supabase
      .from('bills')
      .select(
        `
        *,
        payer:profiles!payer_id(
          full_name,
          username
        ),
        group:groups!group_id(
          group_name
        )
      `
      )
      .eq('group_id', group_id)
      .order('created_at', {
        ascending: false,
      });

    if (error) throw error;

    const mapped = (data || []).map(b => ({
      ...b,
      paid_by_name:
        b.payer?.full_name ||
        b.payer?.username ||
        '—',
      group_name:
        b.group?.group_name || '—',
    }));

    return res.status(200).json({
      success: true,
      data: mapped,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/* ═══════════════════════════════════════════════════════════════
   GET BILL DETAIL
═══════════════════════════════════════════════════════════════ */

export const getBillDetail = async (
  req,
  res
) => {
  try {
    const { bill_id } = req.params;

    const { data, error } = await supabase
      .from('bills')
      .select('*')
      .eq('id', bill_id)
      .single();

    if (error) throw error;

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/* ═══════════════════════════════════════════════════════════════
   GET BILL SPLITS
═══════════════════════════════════════════════════════════════ */

export const getBillSplits = async (
  req,
  res
) => {
  try {
    const { bill_id } = req.params;

    const { data: splits, error } =
      await supabase
        .from('bill_splits')
        .select('*')
        .eq('bill_id', bill_id);

    if (error) throw error;

    return res.status(200).json({
      success: true,
      data: splits,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/* ═══════════════════════════════════════════════════════════════
   UPDATE BILL
═══════════════════════════════════════════════════════════════ */

export const updateBill = async (
  req,
  res
) => {
  try {
    const { bill_id } = req.params;

    const {
      amount,
      description,
      category,
    } = req.body;

    if (
      amount === undefined &&
      description === undefined &&
      category === undefined
    ) {
      return res.status(400).json({
        success: false,
        message:
          'Minimal satu field harus diisi!',
      });
    }

    const updatePayload = {};

    if (amount !== undefined) {
      updatePayload.amount = Number(amount);
    }

    if (description !== undefined) {
      updatePayload.description =
        description;
    }

    if (category !== undefined) {
      updatePayload.category = category;
    }

    const { data, error } = await supabase
      .from('bills')
      .update(updatePayload)
      .eq('id', bill_id)
      .select()
      .single();

    if (error) throw error;

    return res.status(200).json({
      success: true,
      message:
        'Tagihan berhasil diperbarui',
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

/* ═══════════════════════════════════════════════════════════════
   DELETE BILL
═══════════════════════════════════════════════════════════════ */

export const deleteBill = async (
  req,
  res
) => {
  try {
    const { bill_id } = req.params;

    await supabase
      .from('bill_splits')
      .delete()
      .eq('bill_id', bill_id);

    const { data, error } = await supabase
      .from('bills')
      .delete()
      .eq('id', bill_id)
      .select();

    if (error) throw error;

    return res.status(200).json({
      success: true,
      message:
        'Tagihan berhasil dihapus!',
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};